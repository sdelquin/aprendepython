def power(x, n):
    """Calculates powers of numbers.

    :param x: number representing the base of the operation
    :type x: int
    :param n: number representing the exponent of the operation
    :type n: int

    :return: x raised to the power of n
    :rtype: int
    """
    result = 1
    for _ in range(n):
        result *= x
    return result
